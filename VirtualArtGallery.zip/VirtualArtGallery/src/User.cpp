#include "User.h"
#include <iostream>

void User::viewNotifications() const {  // ✅ Proper function definition
    if (notifications.empty()) {
        std::cout << "No new notifications.\n";
        return;
    }
    
    std::cout << "Your Notifications:\n";
    for (const auto& notif : notifications) {
        std::cout << "- " << notif.getMessage() << " (Sent at: " << notif.getTimestamp() << ")" << std::endl;
    }
}