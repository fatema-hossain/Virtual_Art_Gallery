#include <iostream>
#include "Artist.h"
#include "Buyer.h"
#include "Admin.h"
#include "MarketplaceFacade.h"  // ✅ Use the facade for transactions

int main() {
    // Create users
    Artist artist("A1", "Leonardo", "leo@example.com", "password123");
    Buyer buyer("B1", "Alice", "alice@example.com", "securepass");
    Admin admin("AD1", "Fatema", "admin@example.com", "adminpass");

    // Create MarketplaceFacade
    MarketplaceFacade marketplace;

    // Create an artwork
    auto artwork = std::make_unique<Artwork>("ART001", "Starry Night", "Leonardo", 500.0);

    // ✅ Upload artwork through marketplace instead of directly through artist
    marketplace.addArtwork(std::move(artwork));

    // ✅ Purchase artwork through marketplace
    marketplace.purchaseArtwork("Starry Night");

    // ✅ Centralized notifications for all users
    marketplace.sendNotification("Artwork 'Starry Night' has been sold!");

    // View notifications
    std::cout << "\nArtist Notifications:\n";
    artist.viewNotifications();

    std::cout << "\nBuyer Notifications:\n";
    buyer.viewNotifications();

    Artwork starryNight("001", "Starry Night", "Van Gogh", 5000);
    
    std::cout << "\n--- Artwork Details ---\n";
    starryNight.displayInfo();
    
    std::cout << "\n--- Placing Bids ---\n";
    starryNight.placeBid(5500); // First bid
    starryNight.placeBid(6000); // Second bid
    starryNight.placeBid(7000); // Higher bid
    
    std::cout << "\n--- Bid History ---\n";
    starryNight.viewBidHistory();
    
    std::cout << "\n--- Closing Auction ---\n";
    starryNight.closeAuction();

   

    return 0;
}