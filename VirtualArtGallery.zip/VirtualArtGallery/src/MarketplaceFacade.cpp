#include "MarketplaceFacade.h"
#include <iostream>
#include <algorithm>  // ✅ Required for std::find_if
#include <fstream>    // ✅ Required for logging

void MarketplaceFacade::addArtwork(std::unique_ptr<Artwork> artwork) {
    artworks.push_back(std::move(artwork));
    std::cout << "Artwork added successfully!" << std::endl;
}

// ✅ General helper function for transaction handling
void MarketplaceFacade::handleArtworkSale(const std::string& artworkTitle) {
    std::string notificationMessage = "Artwork " + artworkTitle + " has been sold!";
    
    sendNotification(notificationMessage);
    logTransaction(notificationMessage);
}

void MarketplaceFacade::purchaseArtwork(const std::string& artworkTitle) {
    auto it = std::find_if(artworks.begin(), artworks.end(), [&](const std::unique_ptr<Artwork>& art) {
        return art->getTitle() == artworkTitle;
    });

    if (it == artworks.end()) {
        std::cerr << "Error: Artwork not found!" << std::endl;
        logError("Failed purchase attempt for: " + artworkTitle);
        return;
    }

    handleArtworkSale((*it)->getTitle());

    // ✅ Remove artwork from gallery after purchase
    artworks.erase(it);
}

void MarketplaceFacade::sendNotification(const std::string& message) {
    notificationService.sendNotification(message);
}

// ✅ Debugging function to track errors
void MarketplaceFacade::logError(const std::string& errorMessage) {
    std::ofstream errorLog("error.log", std::ios::app);
    if (errorLog.is_open()) {
        errorLog << errorMessage << std::endl;
        errorLog.close();
    } else {
        std::cerr << "Error: Unable to write to log file." << std::endl;
    }
}

void MarketplaceFacade::logTransaction(const std::string& message) {
    std::ofstream logFile("transactions.log", std::ios::app);
    if (logFile.is_open()) {
        logFile << message << std::endl;
        logFile.close();
    } else {
        std::cerr << "Error: Unable to write to log file." << std::endl;
    }
}