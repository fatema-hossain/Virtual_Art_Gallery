#include "BiddingSystem.h"

BiddingSystem::BiddingSystem() : currentBid(0.0), auctionActive(true) {}

void BiddingSystem::placeBid(double bidAmount) {
    if (!auctionActive) {
        std::cout << "Auction has closed. No further bids accepted.\n";
        return;
    }

    if (bidAmount > currentBid) {
        currentBid = bidAmount;
        bidHistory.push_back(bidAmount);
        std::cout << "New bid placed: $" << bidAmount << "\n";
    } else {
        std::cout << "Bid must be higher than the current bid ($" << currentBid << "). Try again.\n";
    }
}

double BiddingSystem::getCurrentBid() const {
    return currentBid;
}

void BiddingSystem::viewBidHistory() const {
    if (bidHistory.empty()) {
        std::cout << "No bids have been placed yet.\n";
        return;
    }

    std::cout << "Bid History:\n";
    for (double bid : bidHistory) {
        std::cout << "- $" << bid << std::endl;
    }
}

void BiddingSystem::closeAuction() {
    auctionActive = false;
    std::cout << "Auction closed. Final bid: $" << currentBid << "\n";
}