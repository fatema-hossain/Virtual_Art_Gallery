#include "NotificationService.h"
#include "Notification.h"  // ✅ Include this to recognize the Notification class
#include <iostream>

void NotificationService::sendNotification(const std::string& message) {
    Notification newNotification(message);
    notifications.push_back(newNotification.getMessage() + " (Sent at: " + newNotification.getTimestamp() + ")");
    std::cout << "Notification sent: " << newNotification.getMessage() << " at " << newNotification.getTimestamp() << std::endl;
}

void NotificationService::viewNotifications() const {
    std::cout << "User Notifications:\n";
    for (const auto& notif : notifications) {
        std::cout << "- " << notif << std::endl;
    }
}