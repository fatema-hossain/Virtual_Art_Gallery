#include "Artwork.h"
#include <iostream>
#include <algorithm>

Artwork::Artwork(std::string id, std::string title, std::string artist, double price)
    : artworkId(id), title(title), artistName(artist), price(price), currentBid(0.0), auctionActive(true) {}

std::string Artwork::getTitle() const {
    return title;
}

double Artwork::getPrice() const {
    return price;
}

void Artwork::displayInfo() const {
    std::cout << "Artwork ID: " << artworkId << "\n"
              << "Title: " << title << "\n"
              << "Artist: " << artistName << "\n"
              << "Price: $" << price << std::endl;

    if (auctionActive) {
        std::cout << "Current Highest Bid: $" << currentBid << "\n";
    } else {
        std::cout << "Auction Closed. Final Price: $" << currentBid << "\n";
    }
}

// 🔥 Bidding System Methods
void Artwork::placeBid(double bidAmount) {
    if (!auctionActive) {
        std::cout << "Bidding for \"" << title << "\" has closed.\n";
        return;
    }

    if (bidAmount > currentBid) {
        currentBid = bidAmount;
        bidHistory.push_back(bidAmount);
        std::cout << "New bid placed: $" << bidAmount << " on \"" << title << "\"\n";
    } else {
        std::cout << "Bid must be higher than the current bid ($" << currentBid << "). Try again.\n";
    }
}

double Artwork::getCurrentBid() const {
    return currentBid;
}

void Artwork::viewBidHistory() const {
    if (bidHistory.empty()) {
        std::cout << "No bids placed for \"" << title << "\" yet.\n";
        return;
    }

    std::cout << "Bid History for \"" << title << "\":\n";
    for (double bid : bidHistory) {
        std::cout << "- $" << bid << std::endl;
    }
}

void Artwork::closeAuction() {
    auctionActive = false;
    std::cout << "Auction for \"" << title << "\" has closed. Final bid: $" << currentBid << "\n";
}