#ifndef NOTIFICATION_H
#define NOTIFICATION_H

#include <string>
#include <chrono>
#include <sstream>
#include <iomanip>

class Notification {
private:
    std::string message;
    std::string timestamp;

public:
    Notification(const std::string& msg) : message(msg) {
        auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
        std::stringstream ss;
        ss << std::put_time(std::localtime(&now), "%Y-%m-%d %H:%M:%S");
        timestamp = ss.str();
    }

    std::string getMessage() const { return message; }
    std::string getTimestamp() const { return timestamp; }
};

#endif // NOTIFICATION_H