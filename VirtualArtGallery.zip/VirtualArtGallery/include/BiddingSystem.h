#ifndef BIDDING_SYSTEM_H
#define BIDDING_SYSTEM_H

#include <vector>
#include <iostream>

class BiddingSystem {
private:
    std::vector<double> bidHistory;
    double currentBid;
    bool auctionActive;

public:
    BiddingSystem();

    void placeBid(double bidAmount);  // ✅ Allows users to bid
    double getCurrentBid() const;     // ✅ Gets highest bid
    void viewBidHistory() const;      // ✅ Shows all bids placed
    void closeAuction();              // ✅ Ends auction & declares final bid
};

#endif // BIDDING_SYSTEM_H