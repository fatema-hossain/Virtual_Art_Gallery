#ifndef MARKETPLACE_FACADE_H
#define MARKETPLACE_FACADE_H

#include "Artwork.h"
#include "PricingStrategy.h"
#include "NotificationService.h"
#include <vector>
#include <memory>
#include <fstream>  // ✅ Required for logging

class MarketplaceFacade {
private:
    std::vector<std::unique_ptr<Artwork>> artworks;
    NotificationService notificationService;

    // ✅ New debugging function
    void logError(const std::string& errorMessage);

public:
    void addArtwork(std::unique_ptr<Artwork> artwork);
    void purchaseArtwork(const std::string& artworkTitle);
    void sendNotification(const std::string& message);
    void logTransaction(const std::string& message);
    void handleArtworkSale(const std::string& artworkTitle);  // ✅ New helper function
};

#endif // MARKETPLACE_FACADE_H