#ifndef ARTWORK_H
#define ARTWORK_H

#include <string>
#include <vector>
#include <iostream>

class Artwork {
protected:
    std::string artworkId;
    std::string title;
    std::string artistName;
    double price;
    
    // 🔥 Bidding System Attributes
    double currentBid;
    std::vector<double> bidHistory;
    bool auctionActive;

public:
    Artwork(std::string id, std::string title, std::string artist, double price);
    
    std::string getTitle() const;
    double getPrice() const;
    void displayInfo() const;

    // 🔥 Bidding System Methods
    void placeBid(double bidAmount);  // ✅ Allows buyers to place bids
    double getCurrentBid() const;     // ✅ Returns the highest bid
    void viewBidHistory() const;      // ✅ Displays bid history
    void closeAuction();              // ✅ Ends bidding and declares the winner
};

#endif // ARTWORK_H