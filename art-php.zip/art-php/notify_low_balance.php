<?php
include 'db.php';

$buyer_id = $_POST["buyer_id"];
$notify_query = "INSERT INTO notifications (user_id, message) VALUES ('$buyer_id', 'Insufficient balance! Please top up your funds.')";
mysqli_query($conn, $notify_query);

echo "Balance warning sent!";
?>