<?php
include 'db.php';

$artwork_id = $_GET["artwork_id"];
$query = "SELECT * FROM bids WHERE artwork_id='$artwork_id' ORDER BY amount DESC";
$result = mysqli_query($conn, $query);

$bids = [];
while ($row = mysqli_fetch_assoc($result)) {
    $bids[] = $row;
}

echo json_encode($bids);
?>