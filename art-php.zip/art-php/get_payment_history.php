
<?php
include 'db.php';

$user_id = $_GET["user_id"];
$query = "SELECT * FROM payments WHERE buyer_id='$user_id' OR artist_id='$user_id' ORDER BY payment_date DESC";
$result = mysqli_query($conn, $query);

$payments = [];
while ($row = mysqli_fetch_assoc($result)) {
    $payments[] = $row;
}

echo json_encode($payments);
?>