<?php
include 'db.php';

$user_id = $_POST["user_id"];
$message = $_POST["message"];

$query = "INSERT INTO notifications (user_id, message) VALUES ('$user_id', '$message')";
mysqli_query($conn, $query);

echo "Notification sent!";
?>