<?php
abstract class Artwork {
    protected $title;
    protected $artist_id;
    protected $price;
    protected $pricing_strategy;

    public function __construct($title, $artist_id, $price, $pricing_strategy) {
        $this->title = $title;
        $this->artist_id = $artist_id;
        $this->price = $price;
        $this->pricing_strategy = $pricing_strategy;
    }

    abstract public function display();
}

class Painting extends Artwork {
    public function display() {
        echo "Displaying Painting: $this->title - Price: $this->price <br>";
    }
}

class Sculpture extends Artwork {
    public function display() {
        echo "Displaying Sculpture: $this->title - Price: $this->price <br>";
    }
}

class ArtworkFactory {
    public static function createArtwork($type, $title, $artist_id, $price, $pricing_strategy) {
        switch ($type) {
            case "Painting":
                return new Painting($title, $artist_id, $price, $pricing_strategy);
            case "Sculpture":
                return new Sculpture($title, $artist_id, $price, $pricing_strategy);
            default:
                throw new Exception("Invalid artwork type");
        }
    }
}
?>