<?php
session_start();
require_once __DIR__ . "/db.php"; // Ensure database connection

// Ensure buyer is logged in
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "buyer") {
    die("Error: Unauthorized access.");
}

$conn = Database::getInstance()->getConnection(); // Get DB connection

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["artwork_id"])) {
    $buyer_id = $_SESSION["user_id"];
    $artwork_id = $_POST["artwork_id"];

    // Retrieve artwork details
    $query = $conn->prepare("SELECT artist_id, price FROM artworks WHERE artwork_id = ? AND pricing_strategy = 'fixed'");
    $query->bind_param("i", $artwork_id);
    $query->execute();
    $result = $query->get_result();

    if ($row = $result->fetch_assoc()) {
        $artist_id = $row["artist_id"];
        $price = $row["price"];

        // Retrieve buyer's balance
        $balance_query = $conn->prepare("SELECT balance FROM users WHERE user_id = ?");
        $balance_query->bind_param("i", $buyer_id);
        $balance_query->execute();
        $balance_result = $balance_query->get_result();

        if ($balance_row = $balance_result->fetch_assoc()) {
            $buyer_balance = $balance_row["balance"];

            // Check if the buyer has enough funds
            if ((float)$buyer_balance < (float)$price) {
                echo "Insufficient balance! Please add funds before purchasing.<br>";
                echo "<a href='add_funds.php'>Click here to add funds</a>";
                exit;
            }

            // Deduct payment from buyer balance
            $update_balance_query = $conn->prepare("UPDATE users SET balance = balance - ? WHERE user_id = ?");
            $update_balance_query->bind_param("di", $price, $buyer_id);
            if (!$update_balance_query->execute()) {
                die("Error deducting balance.");
            }

            // Insert payment record
            $paymentQuery = $conn->prepare("INSERT INTO transactions (buyer_id,artwork_id, amount, transaction_date) VALUES (?, ?, ?, NOW())");
            $paymentQuery->bind_param("iid", $buyer_id, $artwork_id, $price);
            $paymentQuery->execute();

            // Update artwork status to "sold"
            $updateArtworkQuery = $conn->prepare("UPDATE artworks SET pricing_strategy = 'sold' WHERE artwork_id = ?");
            $updateArtworkQuery->bind_param("i", $artwork_id);
            $updateArtworkQuery->execute();

            echo "Purchase successful! Redirecting...";
            header("refresh:2;url=buyer_dashboard.php");
            exit;
        } else {
            echo "Error: Unable to retrieve buyer balance.";
        }
    } else {
        echo "Error: Artwork not available for purchase.";
    }
} else {
    echo "Error: Invalid request.";
}
?>