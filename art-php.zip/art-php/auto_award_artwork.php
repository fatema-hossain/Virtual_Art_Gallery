<?php
include 'db.php';

$artwork_id = $_POST["artwork_id"];
$query = "SELECT buyer_id, MAX(amount) AS highest_bid FROM bids WHERE artwork_id='$artwork_id'";
$result = mysqli_query($conn, $query);
$winner = mysqli_fetch_assoc($result);

if ($winner) {
    $insert_transaction = "INSERT INTO transactions (buyer_id, artwork_id, amount) VALUES ('" . $winner["buyer_id"] . "', '$artwork_id', '" . $winner["highest_bid"] . "')";
    mysqli_query($conn, $insert_transaction);

    $notify_artist = "INSERT INTO notifications (user_id, message) VALUES ((SELECT artist_id FROM artworks WHERE artwork_id='$artwork_id'), 'Your artwork was sold via auction!')";
    mysqli_query($conn, $notify_artist);

    $notify_buyer = "INSERT INTO notifications (user_id, message) VALUES ('" . $winner["buyer_id"] . "', 'You won the auction for artwork ID $artwork_id!')";
    mysqli_query($conn, $notify_buyer);

    echo "Artwork awarded to highest bidder!";
} else {
    echo "No bids placed. Auction ended without a winner.";
}
?>