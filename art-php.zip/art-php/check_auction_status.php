<?php
include 'db.php';

$artwork_id = $_GET["artwork_id"];
$query = "SELECT auction_end_time FROM artworks WHERE artwork_id='$artwork_id'";
$result = mysqli_query($conn, $query);
$auction = mysqli_fetch_assoc($result);

$current_time = date('Y-m-d H:i:s');
if ($auction["auction_end_time"] > $current_time) {
    echo json_encode(["status" => "active", "message" => "Auction is active!"]);
} else {
    echo json_encode(["status" => "ended", "message" => "Auction has ended!"]);
}
?>