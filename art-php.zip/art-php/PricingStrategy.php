<?php
// Define the PricingStrategy interface
interface PricingStrategy {
    public function getPrice();
}

// ✅ Fixed Price Strategy (Standard fixed-price artworks)
class FixedPriceStrategy implements PricingStrategy {
    private $price;

    public function __construct($price) {
        $this->price = $price;
    }

    public function getPrice() {
        return $this->price;
    }
}

// ✅ Auction Price Strategy (Bidding mechanism for auctioned artworks)
class AuctionPriceStrategy implements PricingStrategy {
    private $bids = [];

    public function placeBid($buyer_id, $amount) {
        if ($amount > 0) {
            $this->bids[] = ["buyer_id" => $buyer_id, "amount" => $amount];
        }
    }

    public function getHighestBid() {
        return empty($this->bids) ? 0 : max(array_column($this->bids, 'amount'));
    }

    public function getPrice() {
        return $this->getHighestBid();
    }
}

// ✅ Free Pricing Strategy (Artwork offered for free)
class FreePricing implements PricingStrategy {
    public function getPrice() {
        return 0; // Free artworks always have zero price
    }
}
?>