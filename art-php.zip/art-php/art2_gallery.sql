-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 23, 2025 at 12:00 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `art2_gallery`
--

-- --------------------------------------------------------

--
-- Table structure for table `artworks`
--

CREATE TABLE `artworks` (
  `artwork_id` int(11) NOT NULL,
  `artist_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `image_path` varchar(255) NOT NULL,
  `pricing_strategy` enum('fixed','auction','free') NOT NULL,
  `artwork_type` varchar(50) NOT NULL DEFAULT 'Painting'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `artworks`
--

INSERT INTO `artworks` (`artwork_id`, `artist_id`, `title`, `price`, `image_path`, `pricing_strategy`, `artwork_type`) VALUES
(1, 1, 'Starry Night', 800.00, 'uploads/starry_night.jpg', '', 'Painting'),
(2, 1, 'Modern Abstract', NULL, 'uploads/modern_abstract.jpg', 'auction', 'Painting'),
(3, 1, 'Free Sketch', NULL, 'uploads/free_sketch.jpg', 'free', 'Painting'),
(4, 1, 'a', 1.00, 'uploads/133893584266056847.jpg', '', 'Painting'),
(6, 5, 'b', 5.00, 'uploads/133885506992008621.jpg', '', 'Painting'),
(7, 5, 't', 10.00, 'uploads/133851328833289096.jpg', '', 'Painting'),
(8, 5, 'b', 6.00, 'uploads/half3.png', '', 'Painting'),
(9, 6, 'm', 0.00, 'uploads/27b030af-c01e-433f-861b-cd35dcb1401b.jpg', 'free', 'Painting'),
(10, 5, 'you', 100.00, 'uploads/art_6808b924578ed8.70199271.jpg', '', 'Painting'),
(11, 5, 'm', 1.00, 'uploads/art_6808b979781b44.54467904.jpg', 'auction', 'Painting');

-- --------------------------------------------------------

--
-- Table structure for table `auctions`
--

CREATE TABLE `auctions` (
  `auction_id` int(11) NOT NULL,
  `artwork_id` int(11) NOT NULL,
  `start_price` decimal(10,2) NOT NULL,
  `highest_bid` decimal(10,2) DEFAULT NULL,
  `highest_bidder_id` int(11) NOT NULL,
  `winner_id` int(11) DEFAULT NULL,
  `auction_end_time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `auctions`
--

INSERT INTO `auctions` (`auction_id`, `artwork_id`, `start_price`, `highest_bid`, `highest_bidder_id`, `winner_id`, `auction_end_time`) VALUES
(1, 2, 400.00, 101.00, 2, NULL, '2025-04-19 10:17:21'),
(2, 11, 0.00, NULL, 0, NULL, '2025-04-23 10:05:00');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `user_id`, `message`, `created_at`) VALUES
(1, 1, 'Your artwork \"Starry Night\" has been purchased!', '2025-04-18 04:22:13'),
(2, 2, 'You have successfully purchased \"Starry Night\".', '2025-04-18 04:22:13'),
(3, 2, 'New artwork titled \'you\' is available for purchase!', '2025-04-23 09:55:48'),
(4, 7, 'New artwork titled \'you\' is available for purchase!', '2025-04-23 09:55:48'),
(5, 2, 'New artwork titled \'m\' is available for auction!', '2025-04-23 09:57:13'),
(6, 7, 'New artwork titled \'m\' is available for auction!', '2025-04-23 09:57:13');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method` varchar(50) DEFAULT NULL,
  `payment_status` enum('completed','failed','pending') DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `transaction_id` int(11) NOT NULL,
  `buyer_id` int(11) NOT NULL,
  `seller_id` int(11) DEFAULT NULL,
  `artwork_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transaction_id`, `buyer_id`, `seller_id`, `artwork_id`, `amount`, `transaction_date`) VALUES
(1, 2, NULL, 1, 800.00, '2025-04-18 04:22:13'),
(2, 2, NULL, 4, 1.00, '2025-04-19 10:01:52'),
(3, 2, NULL, 6, 5.00, '2025-04-19 10:02:15'),
(4, 2, NULL, 8, 6.00, '2025-04-19 10:29:57'),
(5, 2, NULL, 7, 10.00, '2025-04-22 14:04:11'),
(6, 7, NULL, 1, 800.00, '2025-04-23 09:53:20'),
(7, 7, NULL, 10, 100.00, '2025-04-23 09:58:01');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('artist','buyer') NOT NULL,
  `balance` decimal(10,2) DEFAULT 1000.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `password`, `role`, `balance`) VALUES
(1, 'Alice Artist', 'alice@example.com', 'hashed_password_1', 'artist', 500.00),
(2, 'Bob Buyer', 'bob@example.com', 'hashed_password_2', 'buyer', 350.00),
(5, 'mini', 'mini@example.com', 'mini', 'artist', 1000.00),
(6, 'salma', 'salma@gmail.com', 'salma', 'artist', 1000.00),
(7, 'meow', 'meow@gmail.com', 'meow', 'buyer', 100.00);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `artworks`
--
ALTER TABLE `artworks`
  ADD PRIMARY KEY (`artwork_id`),
  ADD KEY `artist_id` (`artist_id`);

--
-- Indexes for table `auctions`
--
ALTER TABLE `auctions`
  ADD PRIMARY KEY (`auction_id`),
  ADD KEY `artwork_id` (`artwork_id`),
  ADD KEY `winner_id` (`winner_id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`transaction_id`),
  ADD KEY `buyer_id` (`buyer_id`),
  ADD KEY `artwork_id` (`artwork_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `artworks`
--
ALTER TABLE `artworks`
  MODIFY `artwork_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `auctions`
--
ALTER TABLE `auctions`
  MODIFY `auction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `transaction_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `artworks`
--
ALTER TABLE `artworks`
  ADD CONSTRAINT `artworks_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `auctions`
--
ALTER TABLE `auctions`
  ADD CONSTRAINT `auctions_ibfk_1` FOREIGN KEY (`artwork_id`) REFERENCES `artworks` (`artwork_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `auctions_ibfk_2` FOREIGN KEY (`winner_id`) REFERENCES `users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_ibfk_1` FOREIGN KEY (`buyer_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transactions_ibfk_2` FOREIGN KEY (`artwork_id`) REFERENCES `artworks` (`artwork_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
