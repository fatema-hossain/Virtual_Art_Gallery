<?php
session_start();
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "artist") {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . "/db.php";
$conn = Database::getInstance()->getConnection();

$upload_success = false;
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    try {
        $title = htmlspecialchars(trim($_POST['title']));
        $pricing_strategy = $_POST['pricing_strategy'];
        
        // Validate common inputs
        if (empty($title)) {
            throw new Exception("Artwork title is required");
        }

        // Handle image upload
        $target_dir = "uploads/";
        if (!file_exists($target_dir)) {
            mkdir($target_dir, 0755, true);
        }

        $imageFileType = strtolower(pathinfo($_FILES["image"]["name"], PATHINFO_EXTENSION));
        $allowed_types = ['jpg', 'jpeg', 'png', 'gif'];
        
        if (!in_array($imageFileType, $allowed_types)) {
            throw new Exception("Only JPG, JPEG, PNG & GIF files are allowed.");
        }

        $new_filename = uniqid('art_', true) . '.' . $imageFileType;
        $target_file = $target_dir . $new_filename;

        if (!move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            throw new Exception("Sorry, there was an error uploading your file.");
        }

        // Process based on pricing strategy
        switch ($pricing_strategy) {
            case 'auction':
                $price = floatval($_POST['auction_price']);
                $auction_end_time = $_POST['auction_end_time'];
                
                if ($price <= 0) {
                    throw new Exception("Auction starting price must be greater than zero");
                }
                if (empty($auction_end_time)) {
                    throw new Exception("Auction end time is required");
                }
                
                // Insert artwork
                $stmt = $conn->prepare("INSERT INTO artworks (title, image_path, price, pricing_strategy, artist_id) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("ssdsi", $title, $target_file, $price, $pricing_strategy, $_SESSION["user_id"]);
                $stmt->execute();
                $artwork_id = $stmt->insert_id;

                // Insert into auction
                $insertAuction = $conn->prepare("INSERT INTO auctions (artwork_id, auction_end_time) VALUES (?, ?)");
                $insertAuction->bind_param("is", $artwork_id, $auction_end_time);
                $insertAuction->execute();

                // Notify all buyers
                $message = "New artwork titled '$title' is available for auction!";
                break;

            case 'fixed':
                $price = floatval($_POST['fixed_price']);
                
                if ($price <= 0) {
                    throw new Exception("Fixed price must be greater than zero");
                }
                
                // Insert artwork
                $stmt = $conn->prepare("INSERT INTO artworks (title, image_path, price, pricing_strategy, artist_id) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("ssdsi", $title, $target_file, $price, $pricing_strategy, $_SESSION["user_id"]);
                $stmt->execute();

                // Notify all buyers
                $message = "New artwork titled '$title' is available for purchase!";
                break;

            case 'free':
                $price = 0.00;
                
                // Insert artwork
                $stmt = $conn->prepare("INSERT INTO artworks (title, image_path, price, pricing_strategy, artist_id) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("ssdsi", $title, $target_file, $price, $pricing_strategy, $_SESSION["user_id"]);
                $stmt->execute();

                // Notify all buyers
                $message = "New free artwork titled '$title' is available!";
                break;

            default:
                throw new Exception("Invalid pricing strategy selected");
        }

        // Send notifications to buyers
        $buyers = $conn->query("SELECT user_id FROM users WHERE role = 'buyer'");
        $notifStmt = $conn->prepare("INSERT INTO notifications (user_id, message) VALUES (?, ?)");
        while ($buyer = $buyers->fetch_assoc()) {
            $notifStmt->bind_param("is", $buyer['user_id'], $message);
            $notifStmt->execute();
        }

        $upload_success = true;
    } catch (Exception $e) {
        $error_message = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload Artwork | Art Gallery</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #6C63FF;
            --secondary-color: #4D44DB;
            --light-color: #F8F9FA;
            --dark-color: #343A40;
            --success-color: #28A745;
            --error-color: #DC3545;
            --warning-color: #FFC107;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f5f7;
            color: var(--dark-color);
            line-height: 1.6;
        }
        
        .container {
            max-width: 800px;
            margin: 40px auto;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }
        
        h2 {
            color: var(--primary-color);
            text-align: center;
            margin-bottom: 30px;
            font-weight: 600;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group.hidden {
            display: none;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--dark-color);
        }
        
        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 16px;
            transition: border 0.3s;
        }
        
        input:focus, select:focus, textarea:focus {
            border-color: var(--primary-color);
            outline: none;
            box-shadow: 0 0 0 3px rgba(108, 99, 255, 0.2);
        }
        
        .file-upload {
            position: relative;
            overflow: hidden;
            display: inline-block;
            width: 100%;
        }
        
        .file-upload-input {
            position: absolute;
            left: 0;
            top: 0;
            opacity: 0;
            width: 100%;
            height: 100%;
            cursor: pointer;
        }
        
        .file-upload-label {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 40px 20px;
            border: 2px dashed #ddd;
            border-radius: 8px;
            background-color: #fafafa;
            text-align: center;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .file-upload-label:hover {
            border-color: var(--primary-color);
            background-color: rgba(108, 99, 255, 0.05);
        }
        
        .file-upload-icon {
            font-size: 48px;
            color: var(--primary-color);
            margin-bottom: 10px;
        }
        
        .file-upload-text {
            font-size: 14px;
            color: #666;
        }
        
        .file-upload-preview {
            max-width: 100%;
            max-height: 200px;
            margin-top: 15px;
            display: none;
            border-radius: 4px;
        }
        
        .btn {
            background-color: var(--primary-color);
            color: white;
            border: none;
            padding: 12px 25px;
            font-size: 16px;
            font-weight: 500;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
            text-transform: uppercase;
            letter-spacing: 1px;
        }
        
        .btn:hover {
            background-color: var(--secondary-color);
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-weight: 500;
        }
        
        .alert-success {
            background-color: rgba(40, 167, 69, 0.1);
            color: var(--success-color);
            border: 1px solid rgba(40, 167, 69, 0.3);
        }
        
        .alert-error {
            background-color: rgba(220, 53, 69, 0.1);
            color: var(--error-color);
            border: 1px solid rgba(220, 53, 69, 0.3);
        }
        
        .pricing-info {
            padding: 12px;
            margin-bottom: 20px;
            border-radius: 8px;
            background-color: rgba(108, 99, 255, 0.05);
            border-left: 4px solid var(--primary-color);
        }
        
        .pricing-info.free {
            background-color: rgba(40, 167, 69, 0.05);
            border-left: 4px solid var(--success-color);
        }
        
        .form-footer {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
            color: #666;
        }
        
        @media (max-width: 768px) {
            .container {
                margin: 20px;
                padding: 20px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Upload Your Artwork</h2>
        
        <?php if ($upload_success): ?>
            <div class="alert alert-success">
                Artwork uploaded successfully! <?php 
                    echo $pricing_strategy === 'auction' ? 'Your artwork is now available for auction.' : 
                         ($pricing_strategy === 'fixed' ? 'Your artwork is now available for purchase.' : 
                         'Your free artwork is now available for download.');
                ?>
            </div>
        <?php elseif (!empty($error_message)): ?>
            <div class="alert alert-error">
                <?php echo htmlspecialchars($error_message); ?>
            </div>
        <?php endif; ?>
        
        <form method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="title">Artwork Title</label>
                <input type="text" id="title" name="title" required placeholder="Give your artwork a meaningful title">
            </div>
            
            <div class="form-group">
                <label for="pricing_strategy">Pricing Strategy</label>
                <select id="pricing_strategy" name="pricing_strategy" required>
                    <option value="auction">Auction</option>
                    <option value="fixed">Fixed Price</option>
                    <option value="free">Free Download</option>
                </select>
            </div>
            
            <!-- Auction Fields -->
            <div id="auction-fields" class="form-group">
                <div class="pricing-info">
                    <strong>Auction Information:</strong> Set a starting price and end time for your auction.
                </div>
                <label for="auction_price">Starting Price ($)</label>
                <input type="number" id="auction_price" name="auction_price" step="0.01" min="0.01" placeholder="Enter the starting bid amount">
                
                <label for="auction_end_time">Auction End Date & Time</label>
                <input type="datetime-local" id="auction_end_time" name="auction_end_time">
            </div>
            
            <!-- Fixed Price Fields -->
            <div id="fixed-fields" class="form-group hidden">
                <div class="pricing-info">
                    <strong>Fixed Price Information:</strong> Set a price for immediate purchase.
                </div>
                <label for="fixed_price">Price ($)</label>
                <input type="number" id="fixed_price" name="fixed_price" step="0.01" min="0.01" placeholder="Enter your selling price">
            </div>
            
            <!-- Free Download Fields -->
            <div id="free-fields" class="form-group hidden">
                <div class="pricing-info free">
                    <strong>Free Download:</strong> Share your artwork with the community for free.
                </div>
                <p>Your artwork will be available for free download by all users.</p>
            </div>
            
            <div class="form-group">
                <label>Artwork Image</label>
                <div class="file-upload">
                    <input type="file" id="image" name="image" class="file-upload-input" accept="image/*" required>
                    <label for="image" class="file-upload-label">
                        <div class="file-upload-icon">🖼️</div>
                        <div class="file-upload-text">Click to upload or drag and drop</div>
                        <div class="file-upload-text">PNG, JPG, GIF (Max 5MB)</div>
                        <img id="image-preview" class="file-upload-preview" alt="Preview">
                    </label>
                </div>
            </div>
            
            <button type="submit" class="btn">Upload Artwork</button>
        </form>
        
        <div class="form-footer">
            By uploading, you agree to our Terms of Service and confirm you have rights to this artwork.
        </div>
    </div>

    <script>
        // Image preview functionality
        const fileInput = document.getElementById('image');
        const preview = document.getElementById('image-preview');
        
        fileInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                
                reader.addEventListener('load', function() {
                    preview.style.display = 'block';
                    preview.setAttribute('src', this.result);
                });
                
                reader.readAsDataURL(file);
            }
        });
        
        // Pricing strategy toggle
        const pricingStrategy = document.getElementById('pricing_strategy');
        const auctionFields = document.getElementById('auction-fields');
        const fixedFields = document.getElementById('fixed-fields');
        const freeFields = document.getElementById('free-fields');
        
        pricingStrategy.addEventListener('change', function() {
            // Hide all fields first
            auctionFields.classList.add('hidden');
            fixedFields.classList.add('hidden');
            freeFields.classList.add('hidden');
            
            // Show relevant fields
            switch(this.value) {
                case 'auction':
                    auctionFields.classList.remove('hidden');
                    // Set minimum datetime for auction (current time + 1 hour)
                    const now = new Date();
                    now.setHours(now.getHours() + 1);
                    const minDateTime = now.toISOString().slice(0, 16);
                    document.getElementById('auction_end_time').min = minDateTime;
                    break;
                case 'fixed':
                    fixedFields.classList.remove('hidden');
                    break;
                case 'free':
                    freeFields.classList.remove('hidden');
                    break;
            }
        });
        
        // Initialize the correct fields on page load
        document.addEventListener('DOMContentLoaded', function() {
            pricingStrategy.dispatchEvent(new Event('change'));
        });
    </script>
</body>
</html>