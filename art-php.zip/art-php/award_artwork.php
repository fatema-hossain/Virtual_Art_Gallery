<?php
include 'db.php';

$artwork_id = $_POST["artwork_id"];
$query = "SELECT buyer_id, MAX(amount) AS highest_bid FROM bids WHERE artwork_id='$artwork_id'";
$result = mysqli_query($conn, $query);
$winner = mysqli_fetch_assoc($result);

// Record transaction
$insert_transaction = "INSERT INTO transactions (buyer_id, artwork_id, amount) VALUES ('" . $winner["buyer_id"] . "', '$artwork_id', '" . $winner["highest_bid"] . "')";
mysqli_query($conn, $insert_transaction);

// Notify buyer
$notify_buyer = "INSERT INTO notifications (user_id, message) VALUES ('" . $winner["buyer_id"] . "', 'You won the auction for artwork ID $artwork_id!')";
mysqli_query($conn, $notify_buyer);

echo "Artwork awarded to highest bidder!";
?>