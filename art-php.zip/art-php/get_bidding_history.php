<?php
session_start();
require_once __DIR__ . "/db.php"; // Singleton DB connection

// Validate artwork ID
if (!isset($_GET["artwork_id"])) {
    die(json_encode(["error" => "Artwork ID is required."]));
}

$artwork_id = $_GET["artwork_id"];
$conn = Database::getInstance()->getConnection();

// Retrieve bidding history for the artwork, ordered by most recent bid first
$query = $conn->prepare("SELECT buyer_id, amount, bid_time FROM bids WHERE artwork_id = ? ORDER BY bid_time DESC");
$query->bind_param("i", $artwork_id);
$query->execute();
$result = $query->get_result();

$bidding_history = [];

while ($row = $result->fetch_assoc()) {
    $bidding_history[] = [
        "buyer_id" => $row["buyer_id"],
        "amount" => "$" . number_format($row["amount"], 2),
        "bid_time" => $row["bid_time"]
    ];
}

// Return JSON response
header("Content-Type: application/json");
echo json_encode($bidding_history);
?>