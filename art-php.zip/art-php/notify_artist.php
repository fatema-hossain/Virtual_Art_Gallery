<?php
include 'db.php';

$payment_id = $_POST["payment_id"];
$query = "SELECT artist_id, artwork_id FROM payments WHERE payment_id='$payment_id'";
$result = mysqli_query($conn, $query);
$payment = mysqli_fetch_assoc($result);

if ($payment) {
    $notify_artist = "INSERT INTO notifications (user_id, message) 
                      VALUES ('" . $payment["artist_id"] . "', 'Your artwork ID " . $payment["artwork_id"] . " was sold!')";
    mysqli_query($conn, $notify_artist);

    echo "Notification sent to artist!";
}
?>