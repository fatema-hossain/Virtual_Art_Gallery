<?php
require_once __DIR__ . "/db.php";
$conn = Database::getInstance()->getConnection();
$artist_id = $_SESSION["user_id"];
$days = $_GET["days"] ?? '30';

$salesQuery = $conn->prepare("
    SELECT transaction_id, artwork_id, amount, transaction_date 
    FROM transactions 
    WHERE seller_id = ? AND transaction_date >= NOW() - INTERVAL ? DAY
    ORDER BY transaction_date DESC
");
$salesQuery->bind_param("ii", $artist_id, $days);
$salesQuery->execute();
$salesHistory = $salesQuery->get_result()->fetch_all(MYSQLI_ASSOC);

header("Content-Type: application/json");
echo json_encode($salesHistory);
?>