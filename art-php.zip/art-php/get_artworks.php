<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
require_once __DIR__ . "/db.php"; // ✅ Ensure database connection
require_once __DIR__ . "/Artwork.php"; // ✅ Handles Artwork classes
require_once __DIR__ . "/PricingStrategy.php"; // ✅ Strategy pattern for pricing

$conn = Database::getInstance()->getConnection();

// Fetch all available artworks
$query = $conn->prepare("SELECT artwork_id, title, artist_id, image_path, pricing_strategy, price, artwork_type FROM artworks WHERE pricing_strategy <> 'sold'");
$query->execute();
$result = $query->get_result();

$artworks = [];

while ($row = $result->fetch_assoc()) {
    // ✅ Use ArtworkFactory to create Painting or Sculpture dynamically
    try {
        $artwork = ArtworkFactory::createArtwork(
            $row["artwork_type"], // Ensure this is set in the database
            $row["title"],
            $row["artist_id"],
            $row["image_path"],
            $row["pricing_strategy"],
            $row["price"] ?? 0
        );

        // Store artwork details in response array
        $artworks[] = [
            "artwork_id" => $row["artwork_id"],
            "title" => $row["title"],
            "artist_id" => $row["artist_id"],
            "image_path" => $row["image_path"],
            "pricing_strategy" => $row["pricing_strategy"], // ✅ Add this field
            "pricing" => $artwork->getPrice()
        ];
    } catch (Exception $e) {
        error_log("Error creating artwork: " . $e->getMessage());
        continue; // Skip invalid entries
    }
}

// Return artworks as JSON response for frontend display
header("Content-Type: application/json");
echo json_encode($artworks);
?>