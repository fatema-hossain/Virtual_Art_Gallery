<?php
require_once __DIR__ . "/PricingStrategy.php"; // Ensure pricing strategy classes are available

abstract class Artwork {
    protected $title;
    protected $artist_id;
    protected $image_path;
    protected $pricing_strategy;

    public function __construct($title, $artist_id, $image_path, PricingStrategy $pricing_strategy) {
        $this->title = $title;
        $this->artist_id = $artist_id;
        $this->image_path = $image_path;
        $this->pricing_strategy = $pricing_strategy;
    }

    abstract public function display();

    public function getPrice() {
        return $this->pricing_strategy->getPrice();
    }
}

class Painting extends Artwork {
    public function display() {
        echo "Displaying Painting: $this->title - Price: " . $this->getPrice() . "<br>";
    }
}

class Sculpture extends Artwork {
    public function display() {
        echo "Displaying Sculpture: $this->title - Price: " . $this->getPrice() . "<br>";
    }
}

class ArtworkFactory {
    public static function createArtwork($type, $title, $artist_id, $image_path, $pricing_strategy_type, $base_price = 0) {
        // Determine pricing strategy dynamically
        switch ($pricing_strategy_type) {
            case "fixed":
                $pricing_strategy = new FixedPriceStrategy($base_price);
                break;
            case "auction":
                $pricing_strategy = new AuctionPriceStrategy();
                break;
            case "free":
                $pricing_strategy = new FreePricing();
                break;
            default:
                throw new Exception("Invalid pricing strategy");
        }

        // Create artwork based on type
        switch ($type) {
            case "Painting":
                return new Painting($title, $artist_id, $image_path, $pricing_strategy);
            case "Sculpture":
                return new Sculpture($title, $artist_id, $image_path, $pricing_strategy);
            default:
                throw new Exception("Invalid artwork type");
        }
    }
}
?>