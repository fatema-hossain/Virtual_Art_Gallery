<?php
interface Observer {
    public function update($message);
}

class User implements Observer {
    private $name;
    public function __construct($name) {
        $this->name = $name;
    }
    public function update($message) {
        echo "$this->name received notification: $message <br>";
    }
}

class NotificationService {
    private $observers = [];
    public function addObserver(Observer $observer) {
        $this->observers[] = $observer;
    }
    public function notifyUsers($message) {
        foreach ($this->observers as $observer) {
            $observer->update($message);
        }
    }
}
?>