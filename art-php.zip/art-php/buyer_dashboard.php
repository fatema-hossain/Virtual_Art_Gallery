<?php
session_start();
require_once __DIR__ . "/db.php"; // Singleton Database connection

// Ensure buyer is logged in
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "buyer") {
    header("Location: login.php");
    exit;
}

$conn = Database::getInstance()->getConnection();
$buyer_id = $_SESSION["user_id"];

// ✅ Fetch available artworks (excluding sold)
$availableArtworksQuery = $conn->prepare("
    SELECT artwork_id, title, artist_id, image_path, pricing_strategy, price 
    FROM artworks WHERE pricing_strategy <> 'sold'
");
$availableArtworksQuery->execute();
$availableArtworks = $availableArtworksQuery->get_result()->fetch_all(MYSQLI_ASSOC);

// ✅ Fetch transaction history (purchased artworks)
$transactionQuery = $conn->prepare("
    SELECT t.transaction_id, a.title, a.image_path, t.amount, t.transaction_date 
    FROM transactions t 
    JOIN artworks a ON t.artwork_id = a.artwork_id 
    WHERE t.buyer_id = ? 
    ORDER BY t.transaction_date DESC
");
$transactionQuery->bind_param("i", $buyer_id);
$transactionQuery->execute();
$purchasedArtworks = $transactionQuery->get_result()->fetch_all(MYSQLI_ASSOC);

// ✅ Fetch payment history
$paymentQuery = $conn->prepare("
    SELECT amount, payment_method, payment_status, created_at 
    FROM payments WHERE user_id = ? 
    ORDER BY created_at DESC
");
$paymentQuery->bind_param("i", $buyer_id);
$paymentQuery->execute();
$paymentRecords = $paymentQuery->get_result()->fetch_all(MYSQLI_ASSOC);

// ✅ Fetch notifications
$notificationsQuery = $conn->prepare("
    SELECT message, created_at FROM notifications WHERE user_id = ? 
    ORDER BY created_at DESC
");
$notificationsQuery->bind_param("i", $buyer_id);
$notificationsQuery->execute();
$notifications = $notificationsQuery->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Buyer Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>
    <h1>Welcome, Buyer</h1>
    <nav>
        <ul>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<main>
    <h2>Available Artworks</h2>
    <div id="artwork-gallery">
        <?php foreach ($availableArtworks as $artwork): ?>
            <div class="art-item">
                <h3><?= htmlspecialchars($artwork["title"]) ?></h3>
                <img src="<?= htmlspecialchars($artwork["image_path"]) ?>" alt="<?= htmlspecialchars($artwork["title"]) ?>">
                <p>Price: <?= $artwork["price"] > 0 ? '$' . $artwork["price"] : "Free" ?></p>

                <?php if ($artwork["pricing_strategy"] === "auction"): ?>
                    <form action="place_bid.php" method="POST">
                        <input type="hidden" name="artwork_id" value="<?= $artwork["artwork_id"] ?>">
                        <input type="number" name="bid_amount" placeholder="Enter Bid Amount" required>
                        <button type="submit">Place Bid</button>
                    </form>
                <?php elseif ($artwork["pricing_strategy"] === "fixed" && $artwork["price"] > 0): ?>
                    <form action="buy_artwork.php" method="POST">
                        <input type="hidden" name="artwork_id" value="<?= $artwork["artwork_id"] ?>">
                        <button type="submit">Buy Now</button>
                    </form>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
    </div>

    <h2>Transaction History</h2>
    <div id="transaction-history">
        <?php foreach ($purchasedArtworks as $artwork): ?>
            <p><?= htmlspecialchars($artwork["title"]) ?> - $<?= number_format($artwork["amount"], 2) ?> on <?= htmlspecialchars($artwork["transaction_date"]) ?></p>
        <?php endforeach; ?>
    </div>

    <h2>Payment History</h2>
    <div id="payment-history">
        <?php foreach ($paymentRecords as $payment): ?>
            <p>$<?= number_format($payment["amount"], 2) ?> via <?= htmlspecialchars($payment["payment_method"]) ?> - <?= htmlspecialchars($payment["payment_status"]) ?> on <?= htmlspecialchars($payment["created_at"]) ?></p>
        <?php endforeach; ?>
    </div>

    <h3>Notifications</h3>
    <div id="notifications">
        <?php foreach ($notifications as $notification): ?>
            <p><?= htmlspecialchars($notification["message"]) ?> - <?= htmlspecialchars($notification["created_at"]) ?></p>
        <?php endforeach; ?>
    </div>
</main>

</body>
</html>