<?php
session_start();
require_once __DIR__ . "/db.php"; // Singleton Database Connection
require_once __DIR__ . "/Artwork.php"; // Artwork class for pricing logic
require_once __DIR__ . "/PricingStrategy.php"; // Strategy pattern handling auction prices

// Ensure only buyers can place bids
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "buyer") {
    die(json_encode(["error" => "Unauthorized access."]));
}

$conn = Database::getInstance()->getConnection();

// Get bid details from request
if ($_SERVER["CONTENT_TYPE"] === "application/json") {
    $data = json_decode(file_get_contents("php://input"), true);
    $artwork_id = $data["artwork_id"] ?? null;
    $bid_amount = $data["bid_amount"] ?? null;
} else {
    $artwork_id = $_POST["artwork_id"] ?? null;
    $bid_amount = $_POST["bid_amount"] ?? null;
}

$buyer_id = $_SESSION["user_id"];

// Validate input
if (!$artwork_id || !$bid_amount || !is_numeric($bid_amount) || $bid_amount <= 0) {
    die(json_encode(["error" => "Invalid bid details."]));
}

// Fetch artwork details to confirm it's an auction piece
$query = $conn->prepare("
    SELECT a.artwork_id, a.artist_id, a.title, a.image_path, a.pricing_strategy, 
           au.auction_end_time, au.highest_bid, au.highest_bidder_id
    FROM artworks a
    LEFT JOIN auctions au ON a.artwork_id = au.artwork_id
    WHERE a.artwork_id = ?
");
$query->bind_param("i", $artwork_id);
$query->execute();
$result = $query->get_result();
$artwork_data = $result->fetch_assoc();

if (!$artwork_data || $artwork_data["pricing_strategy"] !== "auction") {
    die(json_encode(["error" => "This artwork is not available for bidding."]));
}

// Check current highest bid
$auctionQuery = $conn->prepare("SELECT highest_bid FROM auctions WHERE artwork_id = ?");
$auctionQuery->bind_param("i", $artwork_id);
$auctionQuery->execute();
$auctionResult = $auctionQuery->get_result();
$auctionData = $auctionResult->fetch_assoc();

if (!$auctionData) {
    die(json_encode(["error" => "Auction data not found for this artwork."]));
}

$current_highest_bid = $auctionData["highest_bid"];

// Ensure the new bid is higher than the current highest bid
if ($bid_amount <= $current_highest_bid) {
    die(json_encode(["error" => "Your bid must be higher than the current highest bid of $" . $current_highest_bid . "."]));
}

// Fetch buyer's current balance
$balanceQuery = $conn->prepare("SELECT balance FROM users WHERE user_id = ?");
$balanceQuery->bind_param("i", $buyer_id);
$balanceQuery->execute();
$balanceResult = $balanceQuery->get_result();
$balanceData = $balanceResult->fetch_assoc();

if (!$balanceData) {
    die(json_encode(["error" => "Unable to fetch buyer's balance."]));
}

$current_balance = $balanceData["balance"];

// Check if auction has ended
$current_time = date('Y-m-d H:i:s');
if ($artwork_data["auction_end_time"] <= $current_time) {
    die(json_encode(["error" => "The auction for this artwork has ended."]));
}

// Update auction price in database and store bid details
$updateQuery = $conn->prepare("UPDATE auctions SET highest_bid = ?, highest_bidder_id = ? WHERE artwork_id = ?");
$updateQuery->bind_param("dii", $bid_amount, $buyer_id, $artwork_id);
if ($updateQuery->execute()) {
    echo json_encode([
        "message" => "Bid placed successfully!",
        "new_highest_bid" => $bid_amount,
        "artwork_id" => $artwork_id,
        "buyer_id" => $buyer_id,
        "current_balance" => $current_balance
    ]);
} else {
    echo json_encode(["error" => "Failed to place bid. Please try again."]);
}
?>