<?php
session_start();
require_once __DIR__ . "/db.php"; // Singleton DB connection

// Ensure artist is logged in
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "artist") {
    header("Location: login.php");
    exit;
}

$conn = Database::getInstance()->getConnection();
$artist_id = $_SESSION["user_id"];

// ✅ Fetch artworks uploaded by artist
$artworksQuery = $conn->prepare("
    SELECT artwork_id, title, price, image_path, pricing_strategy 
    FROM artworks WHERE artist_id = ?
");
$artworksQuery->bind_param("i", $artist_id);
$artworksQuery->execute();
$artworks = $artworksQuery->get_result()->fetch_all(MYSQLI_ASSOC);

// ✅ Fetch transaction history (artworks sold by artist)
$salesQuery = $conn->prepare("
    SELECT t.transaction_id, a.artwork_id, a.title, a.image_path, t.amount, t.transaction_date 
    FROM transactions t 
    JOIN artworks a ON t.artwork_id = a.artwork_id 
    WHERE a.artist_id = ? 
    ORDER BY t.transaction_date DESC
    LIMIT 10
");
$salesQuery->bind_param("i", $artist_id);
$salesQuery->execute();
$salesHistory = $salesQuery->get_result()->fetch_all(MYSQLI_ASSOC);

// ✅ Fetch notifications for artist
$notificationsQuery = $conn->prepare("
    SELECT message, created_at 
    FROM notifications WHERE user_id = ? 
    ORDER BY created_at DESC
");
$notificationsQuery->bind_param("i", $artist_id);
$notificationsQuery->execute();
$notifications = $notificationsQuery->get_result()->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Artist Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<header>
    <h1>Welcome, Artist</h1>
    <nav>
        <ul>
            <li><a href="upload_artwork.php">Upload Artwork</a></li>
            <li><a href="logout.php">Logout</a></li>
        </ul>
    </nav>
</header>

<main>
    <h2>Your Artworks</h2>
    <div id="artist-gallery">
        <?php foreach ($artworks as $artwork): ?>
            <div class="art-item">
                <h3><?= htmlspecialchars($artwork["title"]) ?></h3>
                <img src="<?= htmlspecialchars($artwork["image_path"]) ?>" alt="<?= htmlspecialchars($artwork["title"]) ?>">
                <p>Pricing Strategy: <?= htmlspecialchars($artwork["pricing_strategy"]) ?></p>
            </div>
        <?php endforeach; ?>
    </div>

    <h2>Sales History</h2>
    <div id="sales-history">
        <?php foreach ($salesHistory as $sale): ?>
            <p><strong>Artwork ID:</strong> <?= htmlspecialchars($sale["artwork_id"]) ?> - <strong>Sold for:</strong> $<?= number_format($sale["amount"], 2) ?> on <?= htmlspecialchars($sale["transaction_date"]) ?></p>
        <?php endforeach; ?>
    </div>

    <h3>Notifications</h3>
    <div id="notifications">
        <?php foreach ($notifications as $notification): ?>
            <p><strong>📢</strong> <?= htmlspecialchars($notification["message"]) ?> - <?= htmlspecialchars($notification["created_at"]) ?></p>
        <?php endforeach; ?>
    </div>

    <div id="filters">
        <button onclick="filterSales('7')">Last 7 Days</button>
        <button onclick="filterSales('30')">Last Month</button>
        <button onclick="filterSales('365')">Last Year</button>
    </div>
</main>

<script>
function filterSales(days) {
    fetch(`fetch_sales.php?days=${days}`)
        .then(response => response.json())
        .then(data => {
            let historyDiv = document.getElementById("sales-history");
            historyDiv.innerHTML = "";
            data.forEach(sale => {
                historyDiv.innerHTML += `<p><strong>Artwork:</strong> ${sale.artwork_id} - Sold for $${sale.amount} on ${sale.transaction_date}</p>`;
            });
        });
}
</script>

</body>
</html>