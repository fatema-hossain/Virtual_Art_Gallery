#ifndef IMAGE_PROXY_H
#define IMAGE_PROXY_H

#include "Image.h"
#include <memory>

class ImageProxy : public Image {
private:
    std::shared_ptr<Image> realImage;

public:
    ImageProxy(const std::string& fileName);
    void load() override;
    std::string getPreview() const override;
};

#endif
