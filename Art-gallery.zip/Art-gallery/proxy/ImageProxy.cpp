#include "ImageProxy.h"
#include <iostream>

ImageProxy::ImageProxy(const std::string& fileName)
    : Image(fileName), realImage(nullptr) {}

void ImageProxy::load() {
    if (!realImage) {
        realImage = std::make_shared<Image>(fileName);
        realImage->load();
    }
}

std::string ImageProxy::getPreview() const {
    if (realImage) {
        return realImage->getPreview();
    }
    return "[ImageProxy preview of " + fileName + "]";
}
