#include "Image.h"
#include <iostream>

Image::Image(const std::string& fileName) : fileName(fileName) {}

void Image::load() {
    std::cout << "Loading image from file: " << fileName << std::endl;
}

std::string Image::getPreview() const {
    return "[Preview of " + fileName + "]";
}
