#ifndef IMAGE_H
#define IMAGE_H

#include <string>

class Image {
protected:
    std::string fileName;

public:
    Image(const std::string& fileName);
    virtual void load();                   // Virtual function
    virtual std::string getPreview() const;
    virtual ~Image() = default;
};

#endif
