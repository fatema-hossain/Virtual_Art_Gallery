#include "Marketplace.h"
#include "../utils/PaymentProcessor.h"
#include <iostream>

std::shared_ptr<Marketplace> Marketplace::instance = nullptr;

std::shared_ptr<Marketplace> Marketplace::getInstance() {
    if (instance == nullptr) {
        instance = std::shared_ptr<Marketplace>(new Marketplace());
    }
    return instance;
}

void Marketplace::addArtist(std::shared_ptr<Artist> artist) {
    artists.push_back(artist);
    std::cout << "Artist " << artist->getName() << " added to the marketplace." << std::endl;
}

void Marketplace::addBuyer(std::shared_ptr<Buyer> buyer) {
    buyers.push_back(buyer);
    std::cout << "Buyer " << buyer->getName() << " added to the marketplace." << std::endl;
}

void Marketplace::uploadArtwork(std::shared_ptr<Artist> artist, const std::string& title, const std::string& description,
                                const std::string& imageFile, std::shared_ptr<PricingStrategy> pricingStrategy) {
    std::shared_ptr<Artwork> artwork = std::make_shared<Artwork>(title, description, artist->getName(), imageFile);
    artwork->setPricingStrategy(pricingStrategy);
    artworks.push_back(artwork);
    std::cout << "Artwork uploaded: " << title << " by " << artist->getName() << std::endl;
}

void Marketplace::purchaseArtwork(std::shared_ptr<Buyer> buyer, int artworkIndex) {
    if (artworkIndex >= 0 && artworkIndex < artworks.size()) {
        double price = artworks[artworkIndex]->calculatePrice();
        std::cout << "Buyer " << buyer->getName() << " purchased the artwork for $" << price << std::endl;
    } else {
        std::cout << "Invalid artwork index." << std::endl;
    }
}

void Marketplace::viewArtwork(int artworkIndex) {
    if (artworkIndex >= 0 && artworkIndex < artworks.size()) {
        artworks[artworkIndex]->display();
    } else {
        std::cout << "Invalid artwork index." << std::endl;
    }
}

// Bidding functionality
void Marketplace::placeBid(std::shared_ptr<Buyer> buyer, int artworkIndex, double bidAmount) {
    if (artworkIndex >= 0 && artworkIndex < artworks.size()) {
        artworks[artworkIndex]->placeBid(buyer, bidAmount);
    } else {
        std::cout << "Invalid artwork index for bidding." << std::endl;
    }
}

// Complete purchase functionality
void Marketplace::completePurchase(std::shared_ptr<Buyer> buyer, int artworkIndex) {
    if (artworkIndex >= 0 && artworkIndex < artworks.size()) {
        double price = artworks[artworkIndex]->calculatePrice();
        std::shared_ptr<Transaction> transaction = std::make_shared<Transaction>(buyer, artworks[artworkIndex], price);
        transactions.push_back(transaction);

        // Process payment
        if (PaymentProcessor::processPayment(transaction)) {
            std::cout << "Transaction successful." << std::endl;
        } else {
            std::cout << "Transaction failed." << std::endl;
        }
    } else {
        std::cout << "Invalid artwork index for purchase." << std::endl;
    }
}

// Display transaction history
void Marketplace::displayTransactionHistory() const {
    std::cout << "Transaction History:" << std::endl;
    for (const auto& transaction : transactions) {
        std::cout << "Buyer: " << transaction->getBuyer()->getName()
                  << ", Artwork: " << transaction->getArtwork()->getTitle()
                  << ", Amount: $" << transaction->getAmount()
                  << ", Date: " << transaction->getTimestampString() << std::endl;
    }
}
