#ifndef MARKETPLACE_H
#define MARKETPLACE_H

#include <memory>
#include <vector>
#include "../core/Artist.h"
#include "../core/Buyer.h"
#include "../core/Artwork.h"
#include "../utils/Transaction.h"

class Marketplace {
private:
    static std::shared_ptr<Marketplace> instance;
    std::vector<std::shared_ptr<Artwork>> artworks;
    std::vector<std::shared_ptr<Artist>> artists;
    std::vector<std::shared_ptr<Buyer>> buyers;
    std::vector<std::shared_ptr<Transaction>> transactions;  // Store transactions

    Marketplace() = default;

public:
    static std::shared_ptr<Marketplace> getInstance();

    void addArtist(std::shared_ptr<Artist> artist);
    void addBuyer(std::shared_ptr<Buyer> buyer);
    void uploadArtwork(std::shared_ptr<Artist> artist, const std::string& title, const std::string& description,
                       const std::string& imageFile, std::shared_ptr<PricingStrategy> pricingStrategy);
    void purchaseArtwork(std::shared_ptr<Buyer> buyer, int artworkIndex);
    void viewArtwork(int artworkIndex);
    void placeBid(std::shared_ptr<Buyer> buyer, int artworkIndex, double bidAmount);

    // New methods for payment processing
    void completePurchase(std::shared_ptr<Buyer> buyer, int artworkIndex);
    void displayTransactionHistory() const;
};

#endif // MARKETPLACE_H
