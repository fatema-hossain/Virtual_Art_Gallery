#include "MarketplaceFacade.h"
#include "../singleton/Marketplace.h"
#include <iostream>
#include <memory>

void MarketplaceFacade::uploadArtwork(std::shared_ptr<Artist> artist, const std::string& title,
                                       const std::string& description, const std::string& imageFile,
                                       std::shared_ptr<PricingStrategy> pricingStrategy) {
    std::shared_ptr<Artwork> artwork = std::make_shared<Artwork>(title, description, artist->getName(), imageFile);
    artwork->setPricingStrategy(pricingStrategy);
    artworks.push_back(artwork);
    Marketplace::getInstance()->uploadArtwork(artist, title, description, imageFile, pricingStrategy);
// Artist uploads the artwork
    std::cout << "Artwork uploaded: " << title << " by " << artist->getName() << std::endl;
}

void MarketplaceFacade::viewArtwork(int artworkIndex) {
    if (artworkIndex >= 0 && artworkIndex < artworks.size()) {
        artworks[artworkIndex]->display();
    } else {
        std::cout << "Invalid artwork index." << std::endl;
    }
}

void MarketplaceFacade::purchaseArtwork(std::shared_ptr<Buyer> buyer, int artworkIndex) {
    if (artworkIndex >= 0 && artworkIndex < artworks.size()) {
        double price = artworks[artworkIndex]->calculatePrice();
        std::cout << "Buyer " << buyer->getName() << " purchased the artwork for $" << price << std::endl;
        // You can add more logic for transactions and payment processing here
    } else {
        std::cout << "Invalid artwork index." << std::endl;
    }
}

void MarketplaceFacade::addArtist(std::shared_ptr<Artist> artist) {
    artists.push_back(artist);
    std::cout << "Artist " << artist->getName() << " added to the marketplace." << std::endl;
}

void MarketplaceFacade::addBuyer(std::shared_ptr<Buyer> buyer) {
    buyers.push_back(buyer);
    std::cout << "Buyer " << buyer->getName() << " added to the marketplace." << std::endl;
}
