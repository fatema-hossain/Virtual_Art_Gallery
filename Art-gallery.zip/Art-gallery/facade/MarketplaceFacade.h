#ifndef MARKETPLACE_FACADE_H
#define MARKETPLACE_FACADE_H

#include <memory>
#include <string>
#include <vector>
#include "../core/Artist.h"
#include "../core/Buyer.h"
#include "../core/Artwork.h"
#include "../strategy/PricingStrategy.h"
#include "../proxy/ImageProxy.h"

class MarketplaceFacade {
private:
    // Store for all artworks, artists, and buyers
    std::vector<std::shared_ptr<Artwork>> artworks;
    std::vector<std::shared_ptr<Artist>> artists;
    std::vector<std::shared_ptr<Buyer>> buyers;

public:
    // Method to upload artwork to the marketplace
    void uploadArtwork(std::shared_ptr<Artist> artist, const std::string& title, const std::string& description,
                       const std::string& imageFile, std::shared_ptr<PricingStrategy> pricingStrategy);

    // Method to allow a buyer to view artwork
    void viewArtwork(int artworkIndex);

    // Method to make a purchase
    void purchaseArtwork(std::shared_ptr<Buyer> buyer, int artworkIndex);

    // Method to add artist to marketplace
    void addArtist(std::shared_ptr<Artist> artist);

    // Method to add buyer to marketplace
    void addBuyer(std::shared_ptr<Buyer> buyer);
};

#endif // MARKETPLACE_FACADE_H
