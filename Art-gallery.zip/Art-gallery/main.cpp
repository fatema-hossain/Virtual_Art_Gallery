#include <iostream>
#include "core/Artwork.h"
#include "strategy/PricingStrategy.h"

int main() {
    // Create fixed price strategy with price 100
    std::shared_ptr<PricingStrategy> fixedPrice = std::make_shared<FixedPriceStrategy>(100.0);
    
    // Create artwork with fixed pricing strategy
    Artwork artwork("ART001", "Sunset Vibes", "Beautiful sunset", "Artist01", "2025-04-10");
    artwork.setPricingStrategy(fixedPrice);

    // Display calculated price
    std::cout << "Artwork Price: $" << artwork.calculatePrice() << std::endl;

    // Create auction pricing strategy with base price 50 and highest bid 30
    std::shared_ptr<PricingStrategy> auctionPrice = std::make_shared<AuctionPriceStrategy>(50.0, 30.0);
    
    // Set auction pricing strategy
    artwork.setPricingStrategy(auctionPrice);

    // Display calculated price after changing strategy
    std::cout << "Artwork Auction Price: $" << artwork.calculatePrice() << std::endl;

    return 0;
}
