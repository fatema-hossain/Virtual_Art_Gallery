#include "Artist.h"
#include "Artwork.h"
Artist::Artist(const std::string& id, const std::string& name, const std::string& email)
    : User(id, name, email) {}
void Artist::addArtwork(std::shared_ptr<Artwork> artwork) {
    artworks.push_back(artwork);
}

