#ifndef ARTWORK_H
#define ARTWORK_H
#pragma once

#include <string>
#include <memory>
#include "../proxy/Image.h"
#include "../strategy/PricingStrategy.h"

class Buyer; // Forward declaration

class Artwork {
private:
    std::string id, title, description, artistName, dateCreated;
    std::shared_ptr<PricingStrategy> pricingStrategy;
    std::shared_ptr<Image> image; // ✅ Add this!

public:
    Artwork(const std::string& id, const std::string& title, const std::string& description,
            const std::string& artistName, const std::string& dateCreated);

    void setPricingStrategy(std::shared_ptr<PricingStrategy> strategy);
    void display() const;
    void placeBid(std::shared_ptr<Buyer> buyer, double amount);
    double calculatePrice() const;
    std::string getTitle() const;
    std::shared_ptr<Image> getImage() const; // ✅ Add const
};

#endif
