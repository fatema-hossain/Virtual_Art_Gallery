#include "Artwork.h"
#include "Buyer.h"
#include "../proxy/ImageProxy.h"

#include <iostream>
using namespace std;

Artwork::Artwork(const std::string& id, const std::string& title, const std::string& description,
    const std::string& artistName, const std::string& dateCreated)
: id(id), title(title), description(description), artistName(artistName), dateCreated(dateCreated) {
image = std::make_shared<ImageProxy>("default.jpg"); // You can later add a setter for custom file
}


void Artwork::setPricingStrategy(std::shared_ptr<PricingStrategy> strategy) {
    pricingStrategy = strategy;
}

void Artwork::placeBid(std::shared_ptr<Buyer> buyer, double amount) {
    std::cout << "Bid placed by " << buyer->getName() << " for $" << amount << " on artwork: " << title << std::endl;
}

double Artwork::calculatePrice() const {
    return pricingStrategy ? pricingStrategy->calculatePrice() : 0.0;
}

void Artwork::display() const {
    std::cout << "Title: " << title << "\n"
              << "Description: " << description << "\n"
              << "Artist: " << artistName << "\n"
              << "Price: $" << calculatePrice() << "\n"
              << "Image Preview: " << getImage()->getPreview() << std::endl;

}

std::string Artwork::getTitle() const {
    return title;
}

std::shared_ptr<Image> Artwork::getImage() const { // ✅ Add const
    return image;
}
