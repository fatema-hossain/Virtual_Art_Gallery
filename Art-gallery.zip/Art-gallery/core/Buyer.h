#ifndef BUYER_H
#define BUYER_H
#include "User.h"
class Buyer : public User {
public:
    Buyer(const std::string& id, const std::string& name, const std::string& email);
};
#endif