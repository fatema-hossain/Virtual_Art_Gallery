#include "Buyer.h"
Buyer::Buyer(const std::string& id, const std::string& name, const std::string& email)
    : User(id, name, email) {}


