#ifndef ARTIST_H
#define ARTIST_H

#include "User.h"
#include "Artwork.h"
#include <vector>
#include <memory>

class Artist : public User {
private:
    std::vector<std::shared_ptr<Artwork>> artworks;

public:
    Artist(const std::string& id, const std::string& name, const std::string& email);

    void addArtwork(std::shared_ptr<Artwork> artwork);
    std::vector<std::shared_ptr<Artwork>> getArtworks() const;
    std::string getName() const;
};

#endif
