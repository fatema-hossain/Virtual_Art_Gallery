#include "Transaction.h"
#include "../core/Buyer.h"
#include "../core/Artwork.h"
#include <iostream>
#include <ctime>

Transaction::Transaction(std::shared_ptr<Buyer> buyer, std::shared_ptr<Artwork> artwork, double amount)
    : buyer(buyer), artwork(artwork), amount(amount) {
    timestamp = std::time(nullptr);
}

std::shared_ptr<Buyer> Transaction::getBuyer() const {
    return buyer;
}

std::shared_ptr<Artwork> Transaction::getArtwork() const {
    return artwork;
}

double Transaction::getAmount() const {
    return amount;
}

std::time_t Transaction::getTimestamp() const {
    return timestamp;
}

std::string Transaction::getTimestampString() const {
    std::tm* tm_ptr = std::localtime(&timestamp);
    char buffer[80];
    std::strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", tm_ptr);
    return std::string(buffer);
}
