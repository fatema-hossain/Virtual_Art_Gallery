#ifndef PAYMENTPROCESSOR_H
#define PAYMENTPROCESSOR_H

#include <memory>
#include "Transaction.h"

class PaymentProcessor {
public:
    static bool processPayment(std::shared_ptr<Transaction> transaction);
};

#endif // PAYMENTPROCESSOR_H
