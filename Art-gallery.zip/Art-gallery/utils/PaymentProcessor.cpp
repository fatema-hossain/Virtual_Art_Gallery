#include "PaymentProcessor.h"
#include "Transaction.h"
#include "../core/Buyer.h"
#include "../core/Artwork.h"

#include <iostream>

bool PaymentProcessor::processPayment(std::shared_ptr<Transaction> transaction) {
    // In real-world applications, we would integrate with a payment gateway here.
    // For simplicity, we assume the payment always succeeds.
    std::cout << "Processing payment of $" << transaction->getAmount()
              << " for artwork: " << transaction->getArtwork()->getTitle()
              << " purchased by " << transaction->getBuyer()->getName()
              << " on " << transaction->getTimestampString() << std::endl;
    return true;  // Simulate successful payment processing
}
