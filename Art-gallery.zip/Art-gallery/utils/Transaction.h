#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>
#include <memory>
#include <ctime>

class Buyer;
class Artwork;

class Transaction {
private:
    std::shared_ptr<Buyer> buyer;
    std::shared_ptr<Artwork> artwork;
    double amount;
    std::time_t timestamp;

public:
    Transaction(std::shared_ptr<Buyer> buyer, std::shared_ptr<Artwork> artwork, double amount);

    // Getters
    std::shared_ptr<Buyer> getBuyer() const;
    std::shared_ptr<Artwork> getArtwork() const;
    double getAmount() const;
    std::time_t getTimestamp() const;
    std::string getTimestampString() const;  // Converts timestamp to string format for displaying
};

#endif // TRANSACTION_H
