#ifndef PRICING_STRATEGY_H
#define PRICING_STRATEGY_H

class PricingStrategy {
public:
    virtual ~PricingStrategy() = default;
    virtual double calculatePrice() const = 0;
};

class FixedPriceStrategy : public PricingStrategy {
private:
    double price;

public:
    FixedPriceStrategy(double price);
    double calculatePrice() const override;
};

class AuctionPriceStrategy : public PricingStrategy {
private:
    double basePrice;
    double highestBid;

public:
    AuctionPriceStrategy(double basePrice, double highestBid);
    double calculatePrice() const override;
};

#endif // PRICING_STRATEGY_H
