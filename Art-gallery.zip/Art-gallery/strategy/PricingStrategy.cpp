#include "PricingStrategy.h"

FixedPriceStrategy::FixedPriceStrategy(double price) : price(price) {}

double FixedPriceStrategy::calculatePrice() const {
    return price;
}

AuctionPriceStrategy::AuctionPriceStrategy(double basePrice, double highestBid)
    : basePrice(basePrice), highestBid(highestBid) {}

double AuctionPriceStrategy::calculatePrice() const {
    return basePrice + highestBid;
}
