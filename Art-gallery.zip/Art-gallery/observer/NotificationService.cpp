#include "NotificationService.h"

void NotificationService::addObserver(std::shared_ptr<Observer> observer) {
    observers.push_back(observer);
}

void NotificationService::removeObserver(std::shared_ptr<Observer> observer) {
    observers.erase(std::remove(observers.begin(), observers.end(), observer), observers.end());
}

void NotificationService::notifyObservers(const std::string& message) {
    for (auto& observer : observers) {
        observer->update(message);
    }
}
